EasyRoads3D SRP SUPPORT:
----------------------------

The packages in this folder are Render Pipeline related.

URP or HDRP packages for the installed version will be auto imported. This includes materials for the two provided example road materials. The terrain material in the demo scene
can be upgraded through the Unity built-in SRP material upgrade option. 

Additional info will be available in the "SRP Package Notes" file in the EasyRoads3D root directory after importing the respective SRP package.

There will be a notification when no matching package could be found. In that case please contact us.

Email: info@easyroads3d.com