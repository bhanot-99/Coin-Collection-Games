
Thank you for downloading the free version of EasyRoads3D!


It is recommended to read the manual carefully to get the most out of all the EasyRoads3D features.

Please subscribe to the newletter if you like to receive information about updates.


The manual, including a Quick Start section, is located in the EasyRoads3D root directory.

This is a first release of the free version similar to the previous v2 free version. Any feedback is welcome. The Pro version is still only $45.


Forum: http://forum.unity3d.com/threads/easyroads3d-v3-the-upcoming-new-road-system.229327/
EasyRoads3D Pro: https://www.assetstore.unity3d.com/en/#!/content/469


Website: http://www.easyroads3d.com
Contact: info@easyroads3d.com 
